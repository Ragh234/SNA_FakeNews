import argparse, re, warnings
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import (
    RandomForestClassifier, AdaBoostClassifier,
    GradientBoostingClassifier, BaggingClassifier, VotingClassifier
)
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_recall_fscore_support
import joblib

warnings.filterwarnings("ignore", category=UserWarning)

# ---------- I/O helpers ----------
def read_table(path: str) -> pd.DataFrame:
    path = str(path)
    if path.lower().endswith(".xlsx"):
        return pd.read_excel(path)
    return pd.read_csv(path)

def auto_label_series(series: pd.Series) -> pd.Series:
    lab = series.astype(str).str.lower().str.strip()
    mapping = {"fake": 0, "false": 0, "0": 0, "real": 1, "true": 1, "1": 1}
    y = lab.map(mapping)
    if y.isna().any():
        uniq = lab.dropna().unique().tolist()
        if len(uniq) == 2:
            y = lab.map({uniq[0]: 0, uniq[1]: 1}).astype(int)
        else:
            raise ValueError(f"Ambiguous labels: {uniq}")
    return y.astype(int)

def build_df_from_posts(true_path: str, fake_path: str) -> pd.DataFrame:
    """Combine your True_posts.xlsx and Fake_posts.xlsx"""
    dtr = read_table(true_path)
    dff = read_table(fake_path)

    # Both have columns: 'Statement' (text), 'Type' (label)
    Xr = dtr["Statement"].astype(str)
    Xf = dff["Statement"].astype(str)
    yr = auto_label_series(dtr["Type"])
    yf = auto_label_series(dff["Type"])

    df = pd.concat([
        pd.DataFrame({"text": Xr, "label": yr}),
        pd.DataFrame({"text": Xf, "label": yf})
    ], ignore_index=True)

    return df

# ---------- features ----------
class StyleFeatures(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None): return self
    def transform(self, X):
        out = []
        for s in X:
            s = s if isinstance(s, str) else str(s)
            tokens = re.findall(r"[A-Za-z']+", s.lower())
            n = len(tokens) or 1
            avg_len = sum(len(t) for t in tokens) / n
            exclam = s.count("!") / max(len(s), 1)
            ques = s.count("?") / max(len(s), 1)
            commas = s.count(",") / max(len(s), 1)
            digits = sum(ch.isdigit() for ch in s) / max(len(s), 1)
            upper_ratio = sum(ch.isupper() for ch in s) / max(len(s), 1)
            out.append([n, avg_len, exclam, ques, commas, digits, upper_ratio])
        return np.array(out, dtype=float)

def build_models():
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_df=0.95, sublinear_tf=True)
    feats = FeatureUnion([("tfidf", tfidf), ("style", StyleFeatures())])
    models = {
        "logreg": LogisticRegression(max_iter=2000),
        "linsvc": LinearSVC(),
        "rf": RandomForestClassifier(n_estimators=300, n_jobs=-1, class_weight="balanced_subsample"),
        "ada": AdaBoostClassifier(n_estimators=200, learning_rate=0.5),
        "gboost": GradientBoostingClassifier(),
        "bag_dt": BaggingClassifier(DecisionTreeClassifier(), n_estimators=150, n_jobs=-1),
    }
    voters = [("logreg", models["logreg"]), ("linsvc", models["linsvc"]), ("rf", models["rf"])]
    models["voting"] = VotingClassifier(estimators=voters, voting="hard")
    return feats, models

# ---------- training ----------
def train_eval(df: pd.DataFrame, outdir: Path, cv: int = 0):
    outdir.mkdir(parents=True, exist_ok=True)
    X = df["text"].astype(str).str.replace(r"\s+", " ", regex=True).str.strip()
    y = df["label"].astype(int)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    feats, models = build_models()
    rows = []
    for name, clf in models.items():
        pipe = Pipeline([("feats", feats), ("clf", clf)])
        cv_f1 = None
        if cv and len(ytr.unique()) == 2:
            scores = cross_val_score(pipe, Xtr, ytr, cv=cv, scoring="f1")
            cv_f1 = float(scores.mean())
        print(f"\nTraining {name} ...")
        pipe.fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        acc = accuracy_score(yte, pred)
        p, r, f1, _ = precision_recall_fscore_support(yte, pred, average="binary", zero_division=0)
        cm = confusion_matrix(yte, pred)
        joblib.dump(pipe, outdir / f"{name}.joblib")
        (outdir / f"{name}_report.txt").write_text(classification_report(yte, pred, digits=4))
        np.savetxt(outdir / f"{name}_cm.csv", cm, fmt="%d", delimiter=",")
        rows.append({"model": name, "acc": acc, "precision": p, "recall": r, "f1": f1, "cv_f1": cv_f1})
    pd.DataFrame(rows).to_csv(outdir / "summary.csv", index=False)
    print("\nFinal Summary:")
    print(pd.DataFrame(rows).to_string(index=False))

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--true_posts", type=str, required=True, help="Excel file with TRUE posts")
    ap.add_argument("--fake_posts", type=str, required=True, help="Excel file with FAKE posts")
    ap.add_argument("--out", type=str, default="runs", help="Output directory")
    ap.add_argument("--cv", type=int, default=0, help="Optional cross-validation folds")
    args = ap.parse_args()

    df = build_df_from_posts(args.true_posts, args.fake_posts)
    print(f"Dataset loaded: {len(df)} rows | TRUE={int(df['label'].sum())} | FAKE={len(df)-int(df['label'].sum())}")
    train_eval(df, Path(args.out) / "fake_news_detect", cv=args.cv)

if __name__ == "__main__":
    main()
