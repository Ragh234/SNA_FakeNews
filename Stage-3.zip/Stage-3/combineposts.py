import pandas as pd

# Load both Excel files
true_df = pd.read_excel("True_posts.xlsx")
fake_df = pd.read_excel("fake_posts.xlsx")

# Rename columns consistently
true_df = true_df.rename(columns={"Statement": "text", "Type": "label"})
fake_df = fake_df.rename(columns={"Statement": "text", "Type": "label"})

# Normalize label values
true_df["label"] = 1
fake_df["label"] = 0

# Combine into one dataset
df = pd.concat([true_df[["text", "label"]], fake_df[["text", "label"]]], ignore_index=True)

# Shuffle to mix true and fake rows
df = df.sample(frac=1, random_state=42).reset_index(drop=True)

# Save combined dataset
df.to_csv("all_posts.csv", index=False)

print("✅ Combined dataset created successfully!")
print("Rows:", len(df))
print(df.head())
