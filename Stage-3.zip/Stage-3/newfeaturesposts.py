import argparse
import re
import warnings
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.ensemble import (
    AdaBoostClassifier, BaggingClassifier,
    GradientBoostingClassifier, RandomForestClassifier,
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    precision_recall_fscore_support,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from textblob import TextBlob

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)


# ---------- Text selector ----------
class TextSelector(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None): return self
    def transform(self, X): return X["text"]


# ---------- Read and normalize ----------
def read_table(path: str) -> pd.DataFrame:
    if path.lower().endswith(".xlsx"):
        return pd.read_excel(path)
    return pd.read_csv(path)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    cols = list(df.columns)
    if "text" not in cols:
        df = df.rename(columns={cols[0]: "text"})
    if "label" not in cols:
        df = df.rename(columns={cols[-1]: "label"})
    return df


# ---------- Simplified Linguistic Features ----------
class SimpleLinguisticFeatures(BaseEstimator, TransformerMixin):
    """Adds sentiment polarity score to existing linguistic features."""
    def fit(self, X, y=None): 
        return self

    def transform(self, X):
        feats = []
        for s in X:
            s = "" if s is None else str(s).strip()
            tokens = re.findall(r"[A-Za-z']+", s.lower())
            n_tok = len(tokens)
            uniq = len(set(tokens))
            n_chars = len(s)
            avg_word = np.mean([len(t) for t in tokens]) if tokens else 0.0
            ttr = uniq / (n_tok + 1e-6)
            upper_ratio = sum(ch.isupper() for ch in s) / (len(s) + 1e-6)
            digit_ratio = sum(ch.isdigit() for ch in s) / (len(s) + 1e-6)
            punct_ratio = sum(ch in ".,;:!?-" for ch in s) / (n_chars + 1e-6)
            exclam, quest = s.count("!"), s.count("?")

            # NEW: Sentiment polarity (-1 = negative, +1 = positive)
            polarity = TextBlob(s).sentiment.polarity if s else 0.0

            feats.append([
                n_chars, n_tok, uniq, avg_word, ttr,
                upper_ratio, digit_ratio, punct_ratio,
                exclam, quest, polarity
            ])
        return np.asarray(feats, dtype=float)


# ---------- Build reduced feature set ----------
def build_feature_union(train_df: pd.DataFrame):
    word_tfidf = Pipeline([
        ("select", TextSelector()),
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 1),
            min_df=3,
            max_df=0.75,
            max_features=1500,
            sublinear_tf=True,
            strip_accents="unicode"))
    ])

    ling_feat = Pipeline([
        ("select", TextSelector()),
        ("ling", SimpleLinguisticFeatures())
    ])

    feats = FeatureUnion([
        ("word_tfidf", word_tfidf),
        ("linguistic", ling_feat)
    ])
    return feats


# ---------- Models ----------
def build_models(train_df: pd.DataFrame):
    feats = build_feature_union(train_df)
    models = {
        "logreg": LogisticRegression(max_iter=1500, C=0.7, solver="liblinear", class_weight="balanced"),
        "linsvc": LinearSVC(C=0.05, class_weight=None, max_iter=1000, random_state=42),
        "rf": RandomForestClassifier(n_estimators=100, max_depth=5, n_jobs=-1, random_state=42),
        "ada": AdaBoostClassifier(n_estimators=50, learning_rate=0.18, random_state=42),
        "gboost": GradientBoostingClassifier(max_depth=1, n_estimators=18, learning_rate=0.28, subsample=0.6, random_state=42),
        "bag_dt": BaggingClassifier(DecisionTreeClassifier(max_depth=5), n_estimators=25, max_samples=0.8, n_jobs=-1, random_state=42),
    }
    return feats, models


# ---------- Train & Evaluate ----------
def train_eval(train_df: pd.DataFrame, test_df: pd.DataFrame, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    Xtr, ytr = train_df.drop(columns=["label"]).fillna(""), train_df["label"].astype(int)
    Xte, yte = test_df.drop(columns=["label"]).fillna(""), test_df["label"].astype(int)

    feats, models = build_models(train_df)
    rows = []
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    for name, clf in models.items():
        print(f"\nTraining {name} ...")
        pipe = Pipeline([("features", feats), ("clf", clf)])
        cv_scores = cross_val_score(pipe, Xtr, ytr, cv=cv, scoring="f1")
        mean_cv_f1 = float(np.mean(cv_scores))
        pipe.fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        acc = accuracy_score(yte, pred)
        p, r, f1, _ = precision_recall_fscore_support(yte, pred, average="binary", zero_division=0)
        cm = confusion_matrix(yte, pred)

        joblib.dump(pipe, outdir / f"{name}.joblib")
        (outdir / f"{name}_report.txt").write_text(classification_report(yte, pred, digits=4))
        np.savetxt(outdir / f"{name}_cm.csv", cm, fmt="%d", delimiter=",")

        rows.append({
            "model": name,
            "acc": acc,
            "precision": p,
            "recall": r,
            "f1": f1,
            "cv_f1": mean_cv_f1
        })

    summary = pd.DataFrame(rows)
    summary.sort_values("acc", ascending=False, inplace=True)
    summary.to_csv(outdir / "summary.csv", index=False)
    print("\n=== Final Results ===")
    print(summary.to_string(index=False))

    # Plot accuracy comparison
    plt.figure(figsize=(8, 5))
    plt.bar(summary["model"], summary["acc"])
    plt.ylabel("Accuracy")
    plt.title("Model Test Accuracy (with CV F1 shown in CSV)")
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.savefig(outdir / "accuracy_plot.png")
    plt.close()


# ---------- Main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", required=True, help="Path to train_posts.csv")
    ap.add_argument("--test", required=True, help="Path to test_posts.csv")
    ap.add_argument("--out", default="runs_final_output", help="Output directory")
    args = ap.parse_args()

    train_df = normalize_columns(read_table(args.train))
    test_df = normalize_columns(read_table(args.test))
    train_df["label"] = pd.to_numeric(train_df["label"], errors="coerce").fillna(0).astype(int)
    test_df["label"] = pd.to_numeric(test_df["label"], errors="coerce").fillna(0).astype(int)

    print(f"\n✅ Loaded {len(train_df)} training samples and {len(test_df)} test samples")
    train_eval(train_df, test_df, Path(args.out))


if __name__ == "__main__":
    main()
